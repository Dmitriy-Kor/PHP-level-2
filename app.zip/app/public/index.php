<?php

use app\model\{Products, Users};
use app\model\exc\NormalGoods;
use app\engine\Db;
use app\model\exc\DigitalGoods;

include "../engine/Autoload.php";
include "../model/exc/Autoload.php";
spl_autoload_register([new app\engine\Autoload(), "loadClass"]);

$db = new Db();

// function init(){
//     // инициализаия объектов
// }

$product = new Products($db);
var_dump($product);
echo $product->first(5);

$user = new Users($db);
var_dump($user);
echo $user->get();

$normalGoods = new NormalGoods("Книга", 500, 5);
var_dump($normalGoods);
$normalGoods->showInfo();
$digitalGoods = new DigitalGoods("Электронная книга",  $normalGoods->price, 10, 0, 5);
$digitalGoods->showInfo();

// $db = new Db();
// var_dump($db);
