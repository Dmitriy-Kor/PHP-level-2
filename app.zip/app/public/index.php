<?php
include dirname(__DIR__) . '/config/config.php'; // подключаем конфиг

use app\engine\Autoload;
use app\model\{Products, Users};
use app\model\exc\NormalGoods;
use app\model\exc\DigitalGoods;

include ROOT_DIR . '/engine/Autoload.php';
spl_autoload_register([new Autoload(), 'loadClass']);

// echo __DIR__ . '</br>';
// echo dirname(__DIR__) . '</br>';
// echo $_SERVER['DOCUMENT_ROOT'];


$product = new Products();;
$product = $product->first(2);


//CREATE
$prodNew = new Products('линейка','30см', 30);
$prodNew->insert();


$userNew = new Users('kate', 'kate2000');
$userNew->insert();

//DELETE 
$prodNew->delete(); 
$userNew->delete();

//UPDATE
$prodNew->update();
