<?php
namespace app\interfaces;
interface IModel
{
    // только имена методов
    public function first($id);
    public function get();
    public function getTableName();
}