
<h2><?=$product->name?></h2>
<p>Описание: <?=$product->description?></p>
<p>Цена: <?=$product->price?></p>
