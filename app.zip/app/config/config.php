<?php

define('ROOT_DIR', dirname(__DIR__)); //абсолютный путь
define('CONTROLLER_NAMESPACE', "app\\controllers\\");
define('TEMPLATE_DIR', dirname(__DIR__) . "/templates/");