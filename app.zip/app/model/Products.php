<?php

namespace app\model;

class Products extends Model
{
    public $id;
    public $image;
    public $name;
    public $description;
    public $price;

    //protected $tabelName = "products";
    public function getTableName()
    {
        return "products";
    }
}
