<?php
namespace app\model\exc;

abstract class Products
{
    abstract public function getProfit();
    //abstract public function showInfo();
}