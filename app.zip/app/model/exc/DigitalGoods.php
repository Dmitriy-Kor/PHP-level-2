<?php

namespace app\model\exc;
//use app\model\exc\NormalGoods;

class DigitalGoods extends NormalGoods
{
    public $discount;
    public $price;

    public function __constructor($name = "", $price = null, $qantity = null, $discount = null)
    {
        parent::__construct($name, $qantity);
        $this->discount = $discount;
        $this->price = $price * $discount;
    }
    public function getProfit()
    {
        return $this->qantity * $this->price * $this->discount;
    }
}
