<?php
namespace app\model\exc;
//use app\model\exc\Products;

class NormalGoods extends Products
{
    public $name;
    public $price;
    public $qantity;
    


    public function __construct($name ="", $price = null, $qantity =null)
    {
        $this->name = $name;
        $this->price = $price;
        $this->qantity= $qantity;        
    }

    public function getProfit()
    {   
        return $this->profit = $this->qantity * $this->price;
        
    }
    public function showInfo()
    {   
        echo "<h1>$this->name</h1>
        <p>Количество: $this->qantity</p>
        <p>Цена за штуку: $this->price &#8381</p>
        <p>Итого: {$this->getProfit()} &#8381</p><br>";
    }
}
