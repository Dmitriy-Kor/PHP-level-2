<?php

namespace app\model;

use app\engine\Db;
use app\interfaces\IModel;

abstract class Model implements IModel
{
    // protected $tabelName = '';

    public function first($id)
    {
        $sql = "SELECT * FROM {$this->getTableName()} WHERE id = :id";
        //return Db::getInstance()->queryOne($sql,['id' => $id]);
        return Db::getInstance()->queryObject($sql, ['id' => $id]);
    }
    public function get()
    {
        $sql = "SELECT * FROM {$this->getTableName()}";
        return Db::getInstance()->queryAll($sql);
    }

    public function insert()
    {
        unset($this->id);
        $placeholders =":";
        $params = [];
        foreach ($this as $key => $value) {
            $placeholders .= $key.', :';
            $params[$key] = $value;
        }
        $values = substr((str_replace (":", "" ,$placeholders)), 0 ,-2);
        $placeholders = substr($placeholders, 0, -3);
        
        var_dump($params);
        $sql = "INSERT INTO {$this->getTableName()} ($values) VALUES ($placeholders)";
        echo $sql . '<br>';
        
        Db::getInstance()->execute($sql, $params);
        $this->id = Db::getInstance()->lastInsertId();
        echo "This new id: " . $this->id . '<br>';
    }

    public function delete()
    {
        $sql = "DELETE FROM {$this->getTableName()} WHERE id = :id";
        echo $this->id;
        Db::getInstance()->execute($sql, ['id' => $this->id]);
    }

    public function update()
    {
    $values ="";
    $params =['id' => $this->id];
    unset($this->id);
    foreach($this as $key => $value){
        $values .= $key . " = :" . $key . ", ";
        $params[$key] = $value; 
    }
    $values = substr($values, 0, -2);
    var_dump($params);
    echo $values;

    $sql = "UPDATE {$this->getTableName()} SET {} WHERE id = :id";
    Db::getInstance()->execute($sql, $params);
    //TODO сохранить в объект изменения
    }

    abstract public function getTableName();
}
