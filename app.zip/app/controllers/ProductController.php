<?php

namespace app\controllers;

use app\model\Products;

class ProductController
{
    private $action;
    private $defaultAction = 'index';

    public function runAction($action = null)
    {
        $this->action = $action ?: $this->defaultAction;
        $method = 'action' . ucfirst($this->action);
        if (method_exists($this, $method)) {
            $this->$method();
        } else {
            die('Экшен ' . $method . ' не существует');
        }
    }

    public function actionIndex()
    {
        $catalog = Products::get();
        echo $this->renderTemplate('catalog', ['catalog' => $catalog]);
    }
    public function actionCatalog()
    {
        $products = Products::get();
        var_dump($products);
    }
    public function actionCard()
    {
        $id = (int)$_GET['id'];
        $product = Products::first($id);
        var_dump($product);
        echo "card " . $id;
    }
    
    public function renderTemplate($template, $params = []) {
        ob_start();
        extract($params);
        $templatePath = TEMPLATE_DIR . $template . ".php";
        var_dump($templatePath);
        var_dump($params);
        if (file_exists($templatePath)) {
            include $templatePath;
        }
        return ob_get_clean();
    }
}

