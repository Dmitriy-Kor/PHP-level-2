<?php

namespace app\engine;

class Db
{
    public $conection;

    public function queryOne($sql)
    {
        // выполняем $sql
        return $sql . "<br/>";
    }

    public function queryAll($sql)
    {
        // выполняем $sql
        return $sql . "<br/>";
    }

}
