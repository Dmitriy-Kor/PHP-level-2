<?php

namespace app\engine;

use app\traits\Tsingleton;
//use PDO;

class Db
{
    private $config = [
        'driver' => 'mysql',
        'host' => 'localhost',
        'login' => 'root',
        'password' => 'root',
        'dbname' => 'shop',
        'charset' => 'utf8',
    ];

    use Tsingleton;

    private $conection = null;

    private function getConection()
    {
        if (is_null($this->conection)) {
            $this->conection = new \PDO(
                $this->prepareDsnString(),
                $this->config['login'],
                $this->config['password']
            );
            $this->conection->setAttribute(\PDO::ATTR_DEFAULT_FETCH_MODE, \PDO::FETCH_ASSOC);
            // todo
        }
        return $this->conection;
    }

    private function prepareDsnString()
    {
        return sprintf(
            '%s:host=%s;dbname=%s;charset=%s',
            $this->config['driver'],
            $this->config['host'],
            $this->config['dbname'],
            $this->config['charset']
        );
    }
    //'SELECT * FROM products WHERE id = :id'
    //['id' => 1]
    private function query($sql, $params)
    {
        $proStatment = $this->getConection()->prepare($sql);
        //proStatment->bindParam('id', 1, \PDO::PARAM_INT);
        $proStatment->execute($params);
        return $proStatment;
    }

    public function execute($sql, $params = [])
    {
        return $this->query($sql, $params);
    }

    public function queryObject($sql, $params)
    {
        $proStatment = $this->getConection()->prepare($sql);
        $proStatment->execute($params);
        $proStatment->setFetchMode(\PDO::FETCH_CLASS | \PDO::FETCH_PROPS_LATE, 'Products');
        var_dump($proStatment);

        return $proStatment->fetchAll();
    }

    public function queryOne($sql, $params = [])
    {
        echo $sql . "</br>";
        return $this->query($sql, $params)->fetch();
    }

    public function queryAll($sql, $params = [])
    {
        return $this->query($sql, $params)->fetchAll();
    }
}
